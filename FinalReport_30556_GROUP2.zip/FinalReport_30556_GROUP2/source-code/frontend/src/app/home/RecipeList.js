import React, { useState, useEffect } from "react";
import { Container, Form, Row, Col, InputGroup, Badge } from "react-bootstrap";
import api from "../utils/api";
import { useNavigate } from "react-router-dom";

export const getRecipeImage = (imageUrl) =>
  imageUrl && require(`../../images/recipe_imgs/${imageUrl}`)
    ? require(`../../images/recipe_imgs/${imageUrl}`)
    : require("../../images/default.avif");

const RecipeList = () => {
  const [recipes, setRecipes] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredRecipes, setFilteredRecipes] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        const response = await api.get("/recipes");
        setRecipes(response.data);
        setFilteredRecipes(response.data);
      } catch (error) {
        console.error("Error fetching recipes:", error);
      }
    };

    fetchRecipes();
  }, []);

  useEffect(() => {
    const filtered = recipes.filter((recipe) =>
      recipe.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredRecipes(filtered);
  }, [searchQuery, recipes]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <Container>
      <Row className="justify-content-center" style={{ marginTop: 10 }}>
        <Col sm={6}>
          <InputGroup>
            <Form.Control
              type="text"
              placeholder="Search recipes by title"
              value={searchQuery}
              onChange={handleSearchChange}
              style={{ padding: 14, borderRadius: 16 }}
            />
          </InputGroup>
        </Col>
      </Row>
      <Row className="justify-content-center" style={{ marginTop: 20 }}>
        {filteredRecipes
          .filter((recipe) => recipe.approval_status === "Approved")
          .map((recipe) => (
            <Col key={recipe._id} sm={6} md={4} lg={3} className="mb-4">
              <div
                style={{
                  border: "1px solid #ddd",
                  borderRadius: "10px",
                  overflow: "hidden",
                  cursor: "pointer",
                  transition: "transform 0.2s, box-shadow 0.2s",
                  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                  textAlign: "center",
                  backgroundColor: "#fff",
                  height: "100%",
                }}
                onClick={() => navigate(`/recipes/${recipe._id}/details`)}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "scale(1.05)";
                  e.currentTarget.style.boxShadow =
                    "0 8px 16px rgba(0, 0, 0, 0.2)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "scale(1)";
                  e.currentTarget.style.boxShadow =
                    "0 4px 8px rgba(0, 0, 0, 0.1)";
                }}
              >
                <img
                  src={getRecipeImage(recipe.recipe_image_url)}
                  alt={recipe.title}
                  style={{
                    width: "100%",
                    height: "200px",
                    objectFit: "cover",
                    borderBottom: "1px solid #ddd",
                  }}
                />
                <div style={{ padding: "15px" }}>
                  <h5 style={{ fontWeight: "bold", color: "#333" }}>
                    {recipe.title}
                  </h5>
                  {/* Display premium badge if recipe is premium */}
                  {recipe.is_premium ? (
                    <Badge
                      variant="warning"
                      style={{
                        marginRight: 5,
                        padding: "5px 10px",
                        borderRadius: 10,
                        backgroundColor: "#f0ad4e",
                        color: "#fff",
                        fontWeight: "bold",
                        fontSize: "0.8rem",
                        textTransform: "uppercase",
                      }}
                    >
                      Premium
                    </Badge>
                  ) : (
                    <Badge
                      variant="success"
                      style={{
                        marginRight: 5,
                        padding: "5px 10px",
                        borderRadius: 10,
                        backgroundColor: "#4CAF50",
                        color: "#fff",
                        fontWeight: "bold",
                        fontSize: "0.8rem",
                        textTransform: "uppercase",
                      }}
                    >
                      Free
                    </Badge>
                  )}
                </div>
              </div>
            </Col>
          ))}
      </Row>
    </Container>
  );
};

export default RecipeList;
