import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import Button from "../../components/Button";
import { useNavigate } from "react-router-dom";

const HomePage = () => {
  const cardStyle = {
    height: "200px",
    objectFit: "cover",
    borderRadius: "20px 20px 0 0",
  };
  const navigate = useNavigate();

  return (
    <div>
      {/* Hero Section */}
      <div
        className="hero-section"
        style={{
          padding: "50px 0",
          textAlign: "center",
          backgroundColor: "#f8f9fa",
        }}
      >
        <Container>
          <h1>Welcome to Recipe Management</h1>
          <p className="lead">
            Discover, share, and enjoy mouthwatering recipes from around the
            world.
          </p>
          <Button
            onClick={() => navigate("/search-recipes")}
            variant="primary"
            size="lg"
          >
            Explore Recipes
          </Button>
        </Container>
      </div>

      {/* Featured Recipes Section (Removed) */}

      {/* Additional Content Section */}
      <Container style={{ padding: "50px 0" }}>
        <Row className="justify-content-center">
          <Col md={8}>
            <h2 className="text-center mb-4">Why Choose Us?</h2>
            <p className="text-center">
              At Recipe Management, we're passionate about bringing you the best
              recipes and culinary experiences. Here's why you'll love our
              platform:
            </p>
            <ul className="list-unstyled">
              <li className="mb-3">
                <i className="bi bi-check-circle-fill text-primary me-2"></i>
                <strong>Wide Variety:</strong> Explore a vast collection of
                recipes ranging from traditional favorites to innovative
                creations.
              </li>
              <li className="mb-3">
                <i className="bi bi-check-circle-fill text-primary me-2"></i>
                <strong>User-Friendly:</strong> Our intuitive interface makes it
                easy to find, save, and share your favorite recipes.
              </li>
              <li className="mb-3">
                <i className="bi bi-check-circle-fill text-primary me-2"></i>
                <strong>Community-Driven:</strong> Join a passionate community
                of food lovers, share your recipes, and connect with others.
              </li>
              <li className="mb-3">
                <i className="bi bi-check-circle-fill text-primary me-2"></i>
                <strong>Quality Content:</strong> Every recipe is curated and
                reviewed to ensure only the best make it to your kitchen.
              </li>
            </ul>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default HomePage;
