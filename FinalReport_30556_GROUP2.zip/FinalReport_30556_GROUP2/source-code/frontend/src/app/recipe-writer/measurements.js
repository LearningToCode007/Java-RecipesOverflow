export const measurements = [
  { text: "Grams", value: "grams" },
  { text: "Kilograms", value: "kilograms" },
  { text: "Cups", value: "cups" },
  { text: "Teaspoons", value: "teaspoons" },
  { text: "Tablespoons", value: "tablespoons" },
  { text: "Pounds", value: "pounds" },
  { text: "Oz", value: "oz" },
  { text: "ml", value: "ml" },
  { text: "l", value: "l" },
];
